//
//  HomeTable.swift
//  ECommerceProject.
//
//  Created by Rajith Kumar on 29/06/19.
//  Copyright © 2019 Kunal Poddar. All rights reserved.
//

import UIKit

class HomeTable: UITableView, UITableViewDataSource, UITableViewDelegate {
    //when all the view are loaded in design view
    override func awakeFromNib() {
        self.delegate = self
        self.dataSource = self
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 6
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = indexPath.row
        if row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "FeatureCell", for: indexPath) as! FeatureCell
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "CategoryCell", for: indexPath) as! CategoryCell
            cell.categoryName.text = "women Category"

            return cell
        }
    }
}
