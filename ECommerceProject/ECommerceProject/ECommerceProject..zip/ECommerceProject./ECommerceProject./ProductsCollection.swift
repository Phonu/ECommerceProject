//
//  ProductsCollection.swift
//  ECommerceProject.
//
//  Created by Rajith Kumar on 29/06/19.
//  Copyright © 2019 Kunal Poddar. All rights reserved.
//

import UIKit

class ProductsCollection: UICollectionView, UICollectionViewDelegate, UICollectionViewDataSource{
    
    override func awakeFromNib() {
        self.delegate = self
        self.dataSource = self
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }

    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 6
    }
    

    
    
//    override func numberOfItems(inSection section: Int) -> Int {
//        return 6
//    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProductCell", for: indexPath) as! ProductCell
        
        return cell
        
    }

}
