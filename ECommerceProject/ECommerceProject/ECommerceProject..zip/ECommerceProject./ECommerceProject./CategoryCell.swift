//
//  CategoryCell.swift
//  ECommerceProject.
//
//  Created by Rajith Kumar on 29/06/19.
//  Copyright © 2019 Kunal Poddar. All rights reserved.
//

import UIKit

class CategoryCell: UITableViewCell {

    @IBOutlet weak var categoryName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
