//
//  ProductCell.swift
//  ECommerceProject.
//
//  Created by Rajith Kumar on 29/06/19.
//  Copyright © 2019 Kunal Poddar. All rights reserved.
//

import UIKit

class ProductCell: UICollectionViewCell {
    
}
